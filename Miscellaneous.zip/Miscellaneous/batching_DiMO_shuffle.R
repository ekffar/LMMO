library("DiMO")

optimize_Dreme_Result_With_DiMO <- function(training.pos.file,
                                            training.neg.file,
                                            test.pos.file,
                                            test.neg.file,
                                            motif.file,
                                            motif.width = 8,
                                            out.dir){
  dir.create(out.dir)
  motifs <- read.table(motif.file,header = F)
  motifs.rn <- dim(motifs)[1]
  motifs.n <- motifs.rn / motif.width
  start <- 1
  end <- motifs.rn
  if(motifs.n != 1){
    start <- seq(1,motifs.rn,motif.width)
    end <- c(start[2:motifs.n] - 1,motifs.rn)
  }
  motif.temp.file <- paste(out.dir,"temp.txt",sep = "")
  file.create(motif.temp.file)
  time.file <- paste(out.dir,"time.txt",sep = "")
  write.table(x = "Process time record for DiMO\n",file = time.file,append = F,quote = F,row.names = F,col.names = F)
  auc.file <- paste(out.dir,"auc.txt",sep = "")
  write.table(x = "AUC record for DiMO\n",file = auc.file,append = F,quote = F,row.names = F,col.names = F)
  for(i in c(1:motifs.n)){
    motif <- t(motifs[(start[i]):(end[i]),])
    row.names(motif) <- c("A |","C |","G |","T |")
    write.table("> motif 1",motif.temp.file,row.names = F,col.names = F,quote = F)
    write.table(motif,motif.temp.file,row.names = T,col.names = F,quote = F,append = T)
    time.start <- Sys.time()
    auc.training <- DiMO(positive.file = training.pos.file,
                         negative.file = training.neg.file,
                         pfm.file.name = motif.temp.file,
                         output.flag = paste(out.dir,"motif_",i,sep = ""))
    time.end <- Sys.time()
    write.table(x = c(paste("motif_",i,sep = ""),as.character(difftime(time.end,time.start,units = "secs"))),
                file = time.file,append = T,quote = F,row.names = F,col.names = F)
    auc.test <- computeJustAUC(positive.file = test.pos.file,
                               negative.file = test.neg.file,
                               pfm.file.name = paste(out.dir,"motif_",i,"_END.pfm",sep = ""))
    write.table(x = c(paste("motif_",i,sep = ""),auc.training,auc.test),
                file = auc.file,append = T,quote = F,row.names = F,col.names = F)
  }
}


batching <- function(seq_dir, motif_dir, setname.file, motif.width = 8, fold = 3,out_dir, continue = FALSE){
  setnames <- scan(
    file = setname.file, what = "", sep = "\n", quote = "",allowEscapes = FALSE, quiet = TRUE
  )
  temp.file <- paste(out_dir,"temp.txt",sep = "")
  start <- 1
  if(continue){
    temp <- scan(
      file = temp.file, what = "", sep = "\n", quote = "",allowEscapes = FALSE, quiet = TRUE
    )
    start <- which(setnames == temp)
  }
  end <- length(setnames)
  for(i in c(start:end)){
    write.table(x = setnames[i],file = temp.file,append = F,quote = F,row.names = F,col.names = F)
    for(m in c(1:fold)){
      write(x = paste("#########Start Of Processing ",setnames[i],"_training_",m," #########",sep = ""),file = "")
      training.pos.file <- paste(seq_dir,setnames[i],"_training_",m,"_positive.fasta",sep = "")
      training.neg.file <- paste(seq_dir,setnames[i],"_training_",m,"_negative.fasta",sep = "")
      test.pos.file <- paste(seq_dir,setnames[i],"_test_",m,"_positive.fasta",sep = "")
      test.neg.file <- paste(seq_dir,setnames[i],"_test_",m,"_negative.fasta",sep = "")
      motif.file <- paste(motif_dir,setnames[i],"_training_",m,"-motif.txt",sep = "")
      out.dir <- paste(out_dir,setnames[i],"_training_",m,"/",sep = "")
      optimize_Dreme_Result_With_DiMO(training.pos.file,
                                      training.neg.file,
                                      test.pos.file,
                                      test.neg.file,
                                      motif.file,
                                      motif.width,
                                      out.dir)
      write(x = paste("##########End Of Processing ",setnames[i],"_training_",m," ##########",sep = ""),file = "")
    }
  }
}





