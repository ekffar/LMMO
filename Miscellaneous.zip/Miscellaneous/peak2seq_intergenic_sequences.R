#extract all the intergenic coordinates for a chromosome
#select background seuquences by sample positions from those intergenic regions which have no overlapping with peak region 
library("ChIPpeakAnno")
library("BSgenome.Hsapiens.UCSC.hg19")
library("TxDb.Hsapiens.UCSC.hg19.knownGene")

genic <- genes(TxDb.Hsapiens.UCSC.hg19.knownGene)
genic <- reduce(genic, ignore.strand=T)
intergenic <- gaps(genic)
intergenic <- intergenic[strand(intergenic) == "*"] #both streams
intergenic.chr <- as.vector(intergenic@seqnames)
intergenic.start <- start(intergenic)
intergenic.width <- width(intergenic)
intergenic.num <- length(intergenic.width)

getAllPeakSequence_qiuck <- function(peak.data, genome, useful.cols){
  myPeakList <- BED2RangedData(peak.data[useful.cols], genome,header = F)
  pos.chr <- paste("chr", space(myPeakList), sep = "")  
  pos.strand <- myPeakList$strand
  pos.start <- start(myPeakList)
  pos.end <- end(myPeakList)
  pos.width <- width(myPeakList)
  pos.name <- rownames(myPeakList)
  iRange <- IRanges(start = pos.start, end = pos.end,  names = pos.name)
  fg.gRange <- GRanges(seqnames = pos.chr, ranges = iRange, strand = pos.strand, seqlengths = NULL, seqinfo = NULL)
  fg.seq <- getSeq(genome, fg.gRange, as.character = TRUE)
  names(fg.seq) <- NULL
  
  pos.num <- length(fg.seq)
  pos.start_end <- cbind(pos.start,pos.end,pos.width)
  neg.start_end.function <- function(x){
    intergenic.index <- sample(c(1:intergenic.num),1)
    while(intergenic.width[intergenic.index] < x){
      intergenic.index <- sample(c(1:intergenic.num),1)
    }
    gap <- sample(c(0:(intergenic.width[intergenic.index]-x)),1)
    neg.start <- intergenic.start[intergenic.index] + gap
    neg.end <- intergenic.start[intergenic.index] + gap + x - 1
    return(c(intergenic.index,neg.start,neg.end))
  }
  
  neg.start_end <- sapply(pos.width,neg.start_end.function)
  iRange <- IRanges(start = neg.start_end[2,], end = neg.start_end[3,], names = pos.name)
  bg.gRange <- GRanges(seqnames = intergenic.chr[neg.start_end[1,]], ranges = iRange, strand = pos.strand, seqlengths = NULL, seqinfo = NULL)
  bg.seq <- getSeq(genome, bg.gRange, as.character = TRUE)
  names(bg.seq) <- NULL
  
  return(list(bg.seq = bg.seq))
}

#peak_files.directory: the rood directory of peak files
#genome: the mapping genome sequences 
#out.directory: the directory for storing output positive sequences
peak2seq_intergenic <- function(peak_files.directory,
                                genome,
                                out.directory){
  dir.create(out.directory)
  peak_files.names <- list.files(peak_files.directory)
  peak_files.num <- length(peak_files.names)
  cat("The directory:",peak_files.directory,"has",peak_files.num,"input files.","\n")
  for(m in 1:peak_files.num){
    peak.data <- read.table(paste(peak_files.directory,peak_files.names[m],sep = ""),header = F)
    peak.data <- peak.data[,1:5]
    cat(peak_files.names[m],"has",dim(peak.data)[1],"peaks.","\n")
    row.names(peak.data) <- NULL
    peak.ranger <- BED2RangedData(peak.data, header = F)
    seq.details.pos <- getAllPeakSequence_qiuck(peak.data, genome = genome, c(1:5))
    
    s <- strsplit(peak_files.names[m],"_")
    s <- unlist(s)
    TF.name <- substr(peak_files.names[m],1,(nchar(peak_files.names[m])-1-nchar(s[length(s)])))
    
    seq.num <- length(seq.details.pos$bg.seq)
    out.file <- paste(out.directory,TF.name,"_intergenic.txt",sep = "")
    cat("The",seq.num,"intergenic sequences will be writed to",out.file,"\n")
    temp <- rep("",2*seq.num)
    temp[seq(1,2*seq.num,2)] <- paste(">intergenic.seq",c(1:seq.num))
    temp[seq(2,2*seq.num,2)] <- seq.details.pos$bg.seq      
    write(temp,out.file)
  }
}
