#!/bin/bash
seq_dir=$1
setname_file=$2
out_dir=$3
need_continue=$4
n_fold=50

#polish_shuffle_output /home/sc2/hmmer/temp /home/sc2/hmmer/K562_ARID3A_sc8821_negative.txt
function polish_shuffle_output
{
    input_file=$1
    output_file=$2
    split_char="pos.seq"
    seq_content=""
    cat /dev/null > ${output_file}
    while read content
        do
	    if [[ ${content/${split_char}//} == $content ]] 
	    then
	        temp="$seq_content""$content"	    
	        seq_content=${temp}
	    else
		#content contain split char
		if [ "$seq_content" != "" ]
		then
		    echo ${seq_content} >> ${output_file}
	            seq_content=""
                fi
	        echo ${content/pos/neg} >> ${output_file}
	    fi
    done < $input_file
    echo ${seq_content} >> ${output_file}
}


setname_current=""
mkdir $out_dir
if [ "$need_continue" = "1" ]; then    
    setname_current=`cat ${out_dir}/temp.txt`
fi

cat $setname_file | while read setname 
    do
        if [ "$need_continue" = "1" ]; then
            if [ "$setname_current" = "$setname" ]; then
                need_continue="0"
            fi
        else
            pos_file=${seq_dir}/${setname}_positive.txt
            neg_file=${out_dir}/${setname}_shuffle_1_marcov_${n_fold}fold.txt
            shuffle -n $n_fold -d -1 $pos_file > ${out_dir}/temp_shuffle             
            polish_shuffle_output ${out_dir}/temp_shuffle $neg_file            
            
	    rm ${out_dir}/temp_shuffle             
            echo ${setname} > ${out_dir}/temp.txt
        fi
done

