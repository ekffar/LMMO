#!/bin/bash
seq_dir=$1
setname_file=$2
out_dir=$3
need_continue=$4
motifs_dir=$5
setname_current=""

mkdir $out_dir

if [ "$need_continue" = "1" ]; then    
    setname_current=`cat ${out_dir}/temp.txt`
fi

cat $setname_file | while read setname 
    do
        if [ "$need_continue" = "1" ]; then
            if [ "$setname_current" = "$setname" ]; then
                need_continue="0"
            fi
        else
            pos_file=${seq_dir}/${setname}_positive.fasta
            neg_file=${seq_dir}/${setname}_negative.fasta
            motifs_file=${motifs_dir}/${setname}-motif.txt
            homer2 denovo -i $pos_file -b $neg_file -o ${out_dir}/${setname} -opt $motifs_file -len 8
            echo ${setname} > ${out_dir}/temp.txt
        fi
done
