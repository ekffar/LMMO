library("ChIPpeakAnno")
library("BSgenome.Hsapiens.UCSC.hg19")

getAllPeakSequence_qiuck <- function(peak.data, genome, useful.cols){
  myPeakList <- BED2RangedData(peak.data[useful.cols], genome,header = F)
  pos.chr <- paste("chr", space(myPeakList), sep = "")  
  pos.strand <- myPeakList$strand
  pos.start <- start(myPeakList)
  pos.end <- end(myPeakList)
  pos.width <- width(myPeakList)
  pos.name <- rownames(myPeakList)
  iRange <- IRanges(start = pos.start, end = pos.end,  names = pos.name)
  fg.gRange <- GRanges(seqnames = pos.chr, ranges = iRange, strand = pos.strand, seqlengths = NULL, seqinfo = NULL)
  fg.seq <- getSeq(genome, fg.gRange, as.character = TRUE)
  names(fg.seq) <- NULL
  return(list(fg.seq = fg.seq))
}

#Extract positive sequences from peak data
#peak_files.directory: the rood directory of peak files
#genome: the mapping genome sequences 
#max.seq_num: the maximal sequence number 
#min.seq_num: the minimal sequence number
#max.base_num: the maximal base number of each sequence
#min.base_num: the minimal base number of each sequence
#out.directory: the directory for storing output positive sequences
peak2seq_motifRG <- function(peak_files.directory,
                             genome,
                             max.seq_num  = 0,
                             min.seq_num  = 0,
                             max.base_num  = 0,
                             min.base_num  = 0,
                             out.directory){
  peak_files.names <- list.files(peak_files.directory)
  peak_files.num <- length(peak_files.names)
  cat("The directory:",peak_files.directory,"has",peak_files.num,"input files.","\n")
  temp.peak_num <- NULL
  for(m in 1:peak_files.num){
    peak.data <- read.table(paste(peak_files.directory,peak_files.names[m],sep = ""),header = F)
    peak.data <- peak.data[,1:5]
    cat(peak_files.names[m],"has",dim(peak.data)[1],"peaks.","\n")
    peak.data <- peak.data[which(min.base_num <= (peak.data[,3] - peak.data[,2] + 1) & (peak.data[,3] - peak.data[,2] + 1) <= max.base_num),]
    cat(peak_files.names[m],"has",dim(peak.data)[1],"peaks which have suitable sequence length.","\n")
    temp.peak_num <- c(temp.peak_num,dim(peak.data)[1])
    seq.num <- max.seq_num
    if(min.seq_num <= (dim(peak.data)[1])){
      if((dim(peak.data)[1]) < max.seq_num){
        seq.num <- dim(peak.data)[1]
      }
      else{
        cat("The number of peaks is greater than max.seq_num, so only the top max.seq_num peaks will be saved.","\n")
        peak.data <- peak.data[sort(peak.data[,5],decreasing = T,index.return = T)$ix[1:max.seq_num],]
      }
      row.names(peak.data) <- NULL   
      peak.ranger <- BED2RangedData(peak.data, header = F)
      seq.details <- getAllPeakSequence_qiuck(peak.data, genome = genome, c(1:5))
      s <- strsplit(peak_files.names[m],"_")
      s <- unlist(s)
      TF.name <- substr(peak_files.names[m],1,(nchar(peak_files.names[m])-1-nchar(s[length(s)])))
      seq.num <- length(seq.details$fg.seq)
      out.file <- paste(out.directory,TF.name,"_positive.txt",sep = "")
      cat("The",seq.num,"positive sequences will be writed to",out.file,"\n")
      temp <- rep("",2*seq.num)
      temp[seq(1,2*seq.num,2)] <- paste(">pos.seq",c(1:seq.num))
      temp[seq(2,2*seq.num,2)] <- seq.details$fg.seq      
      write(temp,out.file)
    }
  }
}






















