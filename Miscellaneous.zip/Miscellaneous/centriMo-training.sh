#!/bin/bash

# cd to the directory of datasets
cd /home/dabo/pro2/data/human/combine-3-results-meme/centrimo-4.3/

# create output directory
mkdir ./centriMo-output

# process all the files in "setnames.txt"
cat setnames.txt | while read setname 
do
sequence=${setname}_positive.fasta
pfm=${setname}.txt
centrimo -seqlen 500 -oc centriMo-output/$setname /media/sc2/BED0CCE0D0CCA04F/dabo/43_datasets_motifRG_shuffle/data/centrimo-zhu/training_test_sets_motifRG-500pb/$sequence ./combined/$pfm
done
