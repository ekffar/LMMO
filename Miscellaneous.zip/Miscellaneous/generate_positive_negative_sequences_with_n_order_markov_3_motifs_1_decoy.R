readFasta <- function (file) {
  # read file and tell if file doesnot exist
  if (is.character(file)) {
    file <- file(file, "r")
    on.exit(close(file))
  }
  
  else {
    if (!inherits(file, "connection"))
      stop("'file' must be a character string or connection")
    if (!isOpen(file)) {
      open(file, "r")
      on.exit(close(file))
    }
  }
  
  s1 <- scan(file = file, what = "", sep = "\n", quote = "",allowEscapes = FALSE, quiet = TRUE,blank.lines.skip = T)
  return(s1[-(grep(pattern = ">",x = s1))])
}

# Analysis the statistic characteristics of input sequence with n order Markov
AnalysisSequence <- function(sequence, n.order) {
  sequence.length <- nchar(sequence)
  nmers <- substring(text = sequence, 
                     first = c(1:(sequence.length - n.order)),
                     last = c(n.order:(sequence.length - 1)))
  nmers.table <- table(nmers)
  nmers.pro <- nmers.table/sum(nmers.table)
  nmers.unique <- names(nmers.table)
  char.behind.nmers <- unlist(strsplit(x = substring(text = sequence, first = n.order + 1, last = sequence.length), split = ""))
  
  markov.transform.matrix <- matrix(data = 0, nrow = length(nmers.unique), ncol = 4, dimnames = list(nmers.unique, c("A", "C", "G", "T")))
  for (i in c(1:length(nmers.unique))) {
    nmer.index <- which(nmers == nmers.unique[i])
    chars <- char.behind.nmers[nmer.index]
    temp <- table(chars)
    prob.char <- temp/sum(temp)
    markov.transform.matrix[i,names(prob.char)] <- prob.char
  }
  return(list(n.order = n.order, sequence.length = sequence.length, nmers.pro = nmers.pro, markov.transform.matrix = markov.transform.matrix))
}

# Generate sequence with the analysis results
GenerateSequence <- function(sequence.analysis.result) {
  n.order <- sequence.analysis.result$n.order
  sequence.length <- sequence.analysis.result$sequence.length
  nmers.pro <- sequence.analysis.result$nmers.pro
  markov.transform.matrix <- sequence.analysis.result$markov.transform.matrix
  
  output.sequence <- sample(x = names(nmers.pro), size = 1, prob = nmers.pro)
  n <- n.order
  while(n < sequence.length){
    current.nmer <- substring(text = output.sequence,first = n - n.order + 1,last = n)
    next.char <- sample(x = c("A", "C", "G", "T"), size = 1, prob = markov.transform.matrix[current.nmer,])
    output.sequence <- paste(output.sequence, next.char, sep = "")
    n <- n + 1
  }
  return(output.sequence)
}

#generate a random pwm with specific width and information content
generate_PWM <- function(width, ic) {
  normalize_pwm <- function(p) {
    temp <- apply(p,2,function(x) {
      x <- x - max(x)
      x[which(x < -100)] <- -Inf
      x <- exp(x)
      return(x / sum(x))
    })
    return(temp)
  }
  
  calculate_ic <- function(p) {
    temp <- apply(p, 2, function(x) {
      x <- x[which(x != 0)]
      return(sum(x * log2(x)))
    })
    return(sum(2 + temp))
  }
  
  desired_pwm <- function(pwm, ic, min, max) {
    if (min > max) {
      return(NULL)
    }
    else{
      if (calculate_ic(normalize_pwm(pwm * max)) < ic) {
        return(desired_pwm(pwm, ic, max, max * 2))
      }
      if (calculate_ic(normalize_pwm(pwm * min)) > ic) {
        return(desired_pwm(pwm, ic, min / 2, min))
      }
      s <- (min + max) / 2
      temp.pwm <- normalize_pwm(pwm * s)
      temp.ic <- calculate_ic(temp.pwm)
      if (abs(ic - temp.ic) <= ic * 0.001) {
        return(temp.pwm)
      }
      else if (ic > temp.ic) {
        return(desired_pwm(pwm, ic, s, max))
      }
      else{
        return(desired_pwm(pwm, ic, min, s))
      }
    }
  }
  return(desired_pwm(matrix(
    data = runif(4 * width, 0, 1), nrow = 4,  ncol = width
  ),ic, 1 ,100))
}

#generate signal sequences with PWM
generate_PWM_sequences <- function(pwm,n,single_stranded = F,pos_strand_prob = 0.5) {
  chars_by_site <- function(p,n) {
    temp <- apply(p, 2, function(a,n) {
      return(sample(
        x = c("A","C","G","T"),size = n,replace = T,prob = a
      ))
    },n)
    return(temp)
  }
  
  paste_chars <- function(c) {
    temp <- apply(c, 1, function(a) {
      return(paste(a,collapse = ""))
    })
    return(temp)
  }
  
  reverse_PWM <- function(p) {
    temp <- apply(p, 2, rev)
    return(temp[,dim(p)[2]:1])
  }
  
  pos_strand_seqs <- paste_chars(chars_by_site(pwm,n))
  if (single_stranded) {
    return(list(PWM_sequences = pos_strand_seqs,strands = rep(1,n)))
  }
  else{
    neg_strand_seqs <- paste_chars(chars_by_site(reverse_PWM(pwm),n))
    selected.index <-
      sample(
        x = c(1:(2 * n)),size = n,replace = F,prob = c(rep(pos_strand_prob / n,n),rep((
          1 - pos_strand_prob
        ) / n,n))
      )
    seqs <- c(pos_strand_seqs,neg_strand_seqs)
    strands <- c(rep(1,n),rep(0,n))
    return(list(PWM_sequences = seqs[selected.index],strands = strands[selected.index]))
  }
}

#wirte results to files
write_result <- function(result,director){
  #list(pos.seqs = temp[1,],neg.seqs = neg.seqs,position = temp[2,],pwm_seqs = pwm_seqs)
  file.pos_seq <- paste(director,"positive_sequences.fasta",sep = "")
  file.neg_seq <- paste(director,"negative_sequences.fasta",sep = "")
  file.pwm <- paste(director,"pwm.txt",sep = "")
  file.signal <- paste(director,"signal_motif_mesages.txt",sep = "")
  
  ###########################################################################
  file.decoy.pwm <- paste(director,"decoy_pwm.txt",sep = "")
  file.decoy.pos.signal <- paste(director,"decoy_pos_signal_motif_mesages.txt",sep = "")
  file.decoy.neg.signal <- paste(director,"decoy_neg_signal_motif_mesages.txt",sep = "")
  ###########################################################################
  
  l <- length(result$pos.seqs)
  temp <- rep("",2*l)
  temp[seq(1,2*l,2)] <- paste("> positive_sequence_",c(1:l),sep = "")
  temp[seq(2,2*l,2)] <- result$pos.seqs
  write.table(x = temp,file = file.pos_seq,quote = F,row.names = F,col.names = F)
  
  l <- length(result$neg.seqs)
  temp <- rep("",2*l)
  temp[seq(1,2*l,2)] <- paste("> negative_sequence_",c(1:l),sep = "")
  temp[seq(2,2*l,2)] <- result$neg.seqs
  write.table(x = temp,file = file.neg_seq,quote = F,row.names = F,col.names = F)
  
  write(x = "> motif1",file = file.pwm)
  temp <- result$pwm
  rownames(temp) <- c("A |","C |","G |","T |")
  write.table(x = temp,file = file.pwm,quote = F,append = T,row.names = T,col.names = F)
  
  ###################################################################################
  write(x = "> decoy_motif1",file = file.decoy.pwm)
  temp <- result$decoy.pwm
  rownames(temp) <- c("A |","C |","G |","T |")
  write.table(x = temp,file = file.decoy.pwm,quote = F,append = T,row.names = T,col.names = F)
  ###################################################################################
  
  temp <- cbind(result$position,result$signal_seqs,result$signal_strands)
  temp <- cbind2(paste("positive_sequence_",c(1:length(result$pos.seqs)),sep = ""),temp)
  colnames(temp) <- c("sequence_name","signal_position","signal_sequence","signal_strand")
  write.table(x = temp,file = file.signal,quote = F,row.names = F,col.names = T)
  
  
  ###################################################################################
  temp <- cbind(result$decoy.pos.position,result$decoy.pos.signal_seqs,result$decoy.pos.signal_strands)
  temp <- cbind2(paste("positive_sequence_",c(1:length(result$pos.seqs)),sep = ""),temp)
  colnames(temp) <- c("sequence_name","signal_position","signal_sequence","signal_strand")
  write.table(x = temp,file = file.decoy.pos.signal,quote = F,row.names = F,col.names = T)
  
  temp <- cbind(result$decoy.neg.position,result$decoy.neg.signal_seqs,result$decoy.neg.signal_strands)
  temp <- cbind2(paste("negative_sequence_",c(1:length(result$neg.seqs)),sep = ""),temp)
  colnames(temp) <- c("sequence_name","signal_position","signal_sequence","signal_strand")
  write.table(x = temp,file = file.decoy.neg.signal,quote = F,row.names = F,col.names = T)
  ###################################################################################
}

#generate positive and negative sequences and insert 3-motifs
generate_sequences_3_motifs <- function(pos_seqs,neg_seqs,seq_len,seq_num,implantation_prob = c(0.9,0.8,0.7),
                                        motif_width,ic,
                                        single_stranded = F,pos_strand_prob = 0.5,
                                        decoy.implantation_prob,decoy.motif_width,decoy.ic,
                                        decoy.single_stranded = F,decoy.pos_strand_prob = 0.5,
                                        director) {
  all_seqs <- pos_seqs
  all_seqs.len <- nchar(all_seqs)
  seqs <- substr(x = all_seqs[which(all_seqs.len >= seq_len)],start = 1,stop = seq_len)
  if(length(seqs) >= seq_num){
    seqs <- seqs[1:seq_num]
  }else{
    stop()
  }
  pos.seqs <- seqs
  
  all_seqs <- neg_seqs
  all_seqs.len <- nchar(all_seqs)
  seqs <- substr(x = all_seqs[which(all_seqs.len >= seq_len)],start = 1,stop = seq_len)
  if(length(seqs) >= seq_num){
    seqs <- seqs[1:seq_num]
  }else{
    stop()
  }
  neg.seqs <- seqs
  
  insert_motif_to_seq <- function(x){
    seq_in <- x[1]
    motif <- x[2]
    masked_pos <- as.integer(x[-c(1:2)])
    
    char_num <- nchar(seq_in)
    available_position <- c(1:(char_num-motif_width+1))
    if(any(masked_pos != 0)){
      masked_pos <- masked_pos[which(masked_pos != 0)]
      temp.start <- masked_pos - motif_width + 1
      temp.end <- masked_pos+motif_width-1
      temp <- NULL
      for(i in c(1:(length(temp.start)))){
        temp <- c(temp,c((temp.start[i]):(temp.end[i])))
      }
      temp[which(temp <= 0)] <- 1
      temp[which(temp > (char_num-motif_width+1))] <-  (char_num-motif_width+1)
      available_position <- available_position[-temp]
    }
    start <- sample(x = available_position,size = 1)
    substr(x = x[1],start = start,stop = start + motif_width - 1) <- x[2]
    return(c(x[1],start))
  }
  
  selected.index <-
    sample(x = c(TRUE,FALSE),size = seq_num,replace = T,prob = c(implantation_prob[1],1-(implantation_prob[1])))
  pos.num <- length(which(selected.index == TRUE))
  pwm <- generate_PWM(motif_width,ic)
  pwm_seqs <-
    generate_PWM_sequences(pwm,pos.num,single_stranded,pos_strand_prob)
  temp <-
    apply(X = cbind(pos.seqs[selected.index],pwm_seqs$PWM_sequences,rep(0,pos.num)), 
          MARGIN = 1, FUN = insert_motif_to_seq)
  
  pos.seqs[selected.index] <- temp[1,]
  position <- rep(0,seq_num)
  position[selected.index] <- temp[2,]
  signal_seqs <- rep("NA",seq_num)
  signal_seqs[selected.index] <- pwm_seqs$PWM_sequences
  signal_strands <- rep(-1,seq_num)
  signal_strands[selected.index] <- pwm_seqs$strands
  
  decoy.pwm <- generate_PWM(decoy.motif_width,decoy.ic)
  decoy.selected.index <-
    sample(x = c(TRUE,FALSE),size = seq_num,replace = T,prob = c(decoy.implantation_prob,1-decoy.implantation_prob))
  decoy.num <- length(which(decoy.selected.index == TRUE))
  decoy.pwm_seqs <-
    generate_PWM_sequences(decoy.pwm,decoy.num,decoy.single_stranded,decoy.pos_strand_prob)
  temp <-
    apply(X = cbind(pos.seqs[decoy.selected.index],decoy.pwm_seqs$PWM_sequences,position[decoy.selected.index]), 
          MARGIN = 1, FUN = insert_motif_to_seq)
  
  pos.seqs[decoy.selected.index] <- temp[1,]
  decoy.pos.position <- rep(0,seq_num)
  decoy.pos.position[decoy.selected.index] <- temp[2,]
  decoy.pos.signal_seqs <- rep("NA",seq_num)
  decoy.pos.signal_seqs[decoy.selected.index] <- decoy.pwm_seqs$PWM_sequences
  decoy.pos.signal_strands <- rep(-1,seq_num)
  decoy.pos.signal_strands[decoy.selected.index] <- decoy.pwm_seqs$strands
  
  decoy.selected.index <-
    sample(x = c(TRUE,FALSE),size = seq_num,replace = T,prob = c(decoy.implantation_prob,1-decoy.implantation_prob))
  decoy.num <- length(which(decoy.selected.index == TRUE))
  decoy.pwm_seqs <-
    generate_PWM_sequences(decoy.pwm,decoy.num,decoy.single_stranded,decoy.pos_strand_prob)
  temp <-
    apply(cbind(neg.seqs[decoy.selected.index],decoy.pwm_seqs$PWM_sequences), 1, function(x) {
      s1.l <- nchar(x[1])
      s2.l <- nchar(x[2])
      start <- sample(x = c(1:(s1.l - s2.l + 1)),size = 1)
      substr(x = x[1],start = start,stop = start + s2.l - 1) <- x[2]
      return(c(x[1],start))
    })
  neg.seqs[decoy.selected.index] <- temp[1,]
  decoy.neg.position <- rep(0,seq_num)
  decoy.neg.position[decoy.selected.index] <- temp[2,]
  decoy.neg.signal_seqs <- rep("NA",seq_num)
  decoy.neg.signal_seqs[decoy.selected.index] <- decoy.pwm_seqs$PWM_sequences
  decoy.neg.signal_strands <- rep(-1,seq_num)
  decoy.neg.signal_strands[decoy.selected.index] <- decoy.pwm_seqs$strands
  
  result <- list(
    pos.seqs = pos.seqs,neg.seqs = neg.seqs,pwm = pwm,position = position,signal_seqs = signal_seqs,signal_strands = signal_strands,
    decoy.pwm = decoy.pwm,decoy.pos.position = decoy.pos.position,decoy.pos.signal_seqs = decoy.pos.signal_seqs,decoy.pos.signal_strands = decoy.pos.signal_strands,
    decoy.neg.position = decoy.neg.position,decoy.neg.signal_seqs = decoy.neg.signal_seqs,decoy.neg.signal_strands = decoy.neg.signal_strands
  )
  
  dir.create(director)
  dir.create(paste(director,"motif-1/",sep = ""))
  write_result(result,paste(director,"motif-1/",sep = ""))
  
  motif2_selected.index <-
    sample(x = c(TRUE,FALSE),size = seq_num,replace = T,prob = c(implantation_prob[2],1-(implantation_prob[2])))
  motif2_pos.num <- length(which(motif2_selected.index == TRUE))
  motif2_pwm <- generate_PWM(motif_width,ic)
  motif2_pwm_seqs <-
    generate_PWM_sequences(motif2_pwm,motif2_pos.num,single_stranded,pos_strand_prob)
  temp <-
    apply(X = cbind(pos.seqs[motif2_selected.index],motif2_pwm_seqs$PWM_sequences,position[motif2_selected.index],decoy.pos.position[motif2_selected.index]),
          MARGIN = 1, FUN = insert_motif_to_seq)
  
  pos.seqs[motif2_selected.index] <- temp[1,]
  motif2_position <- rep(0,seq_num)
  motif2_position[motif2_selected.index] <- temp[2,]
  motif2_signal_seqs <- rep("NA",seq_num)
  motif2_signal_seqs[motif2_selected.index] <- motif2_pwm_seqs$PWM_sequences
  motif2_signal_strands <- rep(-1,seq_num)
  motif2_signal_strands[motif2_selected.index] <- motif2_pwm_seqs$strands
  
  result <- list(
    pos.seqs = pos.seqs,neg.seqs = neg.seqs,pwm = motif2_pwm,position = motif2_position,signal_seqs = motif2_signal_seqs,signal_strands = motif2_signal_strands,
    decoy.pwm = decoy.pwm,decoy.pos.position = decoy.pos.position,decoy.pos.signal_seqs = decoy.pos.signal_seqs,decoy.pos.signal_strands = decoy.pos.signal_strands,
    decoy.neg.position = decoy.neg.position,decoy.neg.signal_seqs = decoy.neg.signal_seqs,decoy.neg.signal_strands = decoy.neg.signal_strands
  )
  dir.create(paste(director,"motif-2/",sep = ""))
  write_result(result,paste(director,"motif-2/",sep = ""))
  
  
  motif3_selected.index <-
    sample(x = c(TRUE,FALSE),size = seq_num,replace = T,prob = c(implantation_prob[3],1-(implantation_prob[3])))
  motif3_pos.num <- length(which(motif3_selected.index == TRUE))
  motif3_pwm <- generate_PWM(motif_width,ic)
  motif3_pwm_seqs <-
    generate_PWM_sequences(motif3_pwm,motif3_pos.num,single_stranded,pos_strand_prob)
  temp <-
    apply(X = cbind(pos.seqs[motif3_selected.index],motif3_pwm_seqs$PWM_sequences,position[motif3_selected.index],motif2_position[motif3_selected.index],decoy.pos.position[motif3_selected.index]),
          MARGIN = 1, FUN = insert_motif_to_seq)
  
  pos.seqs[motif3_selected.index] <- temp[1,]
  motif3_position <- rep(0,seq_num)
  motif3_position[motif3_selected.index] <- temp[2,]
  motif3_signal_seqs <- rep("NA",seq_num)
  motif3_signal_seqs[motif3_selected.index] <- motif3_pwm_seqs$PWM_sequences
  motif3_signal_strands <- rep(-1,seq_num)
  motif3_signal_strands[motif3_selected.index] <- motif3_pwm_seqs$strands
  
  result <- list(
    pos.seqs = pos.seqs,neg.seqs = neg.seqs,pwm = motif3_pwm,position = motif3_position,signal_seqs = motif3_signal_seqs,signal_strands = motif3_signal_strands,
    decoy.pwm = decoy.pwm,decoy.pos.position = decoy.pos.position,decoy.pos.signal_seqs = decoy.pos.signal_seqs,decoy.pos.signal_strands = decoy.pos.signal_strands,
    decoy.neg.position = decoy.neg.position,decoy.neg.signal_seqs = decoy.neg.signal_seqs,decoy.neg.signal_strands = decoy.neg.signal_strands
  )
  dir.create(paste(director,"motif-3/",sep = ""))
  write_result(result,paste(director,"motif-3/",sep = ""))
}

GeneratePositiveNegativeSequencesWithMarkov <- function(input.sequences.file, n.order, 
                                                        seq_len, seq_num, implantation_prob,
                                                        motif_width, ic,
                                                        single_stranded = F, pos_strand_prob = 0.5,
                                                        decoy.implantation_prob, decoy.motif_width,decoy.ic,
                                                        decoy.single_stranded = F,decoy.pos_strand_prob = 0.5,
                                                        output.dir) {
  sequences <- readFasta(input.sequences.file)
  sequence.n <- length(sequences)
  positive.sequences <- NULL
  negative.sequences <- NULL
  for(i in c(1:sequence.n)) {
    sequence.analysis.result <- AnalysisSequence(sequences[i], n.order)
    positive.sequences <- c(positive.sequences,
                            GenerateSequence(sequence.analysis.result))
    negative.sequences <- c(negative.sequences,
                            GenerateSequence(sequence.analysis.result))
  }
  generate_sequences_3_motifs (positive.sequences,negative.sequences,seq_len,seq_num,implantation_prob,
                               motif_width,ic,
                               single_stranded = F,pos_strand_prob = 0.5,
                               decoy.implantation_prob,decoy.motif_width,decoy.ic,
                               decoy.single_stranded = F,decoy.pos_strand_prob = 0.5,
                               output.dir)
}

# test commands
# GeneratePositiveNegativeSequencesWithMarkov (input.sequences.file = "/home/dabo/Documents/input_foreground_sequences.fasta", n.order = 2, 
#                                              seq_len = 500, seq_num = 5, implantation_prob = c(0.9,0.8,0.7),
#                                              motif_width = 8, ic = 12,
#                                              single_stranded = F, pos_strand_prob = 0.5,
#                                              decoy.implantation_prob = 0.6, decoy.motif_width = 8,decoy.ic = 10,
#                                              decoy.single_stranded = F,decoy.pos_strand_prob = 0.5,
#                                              output.dir = "/home/dabo/Documents/test/")
